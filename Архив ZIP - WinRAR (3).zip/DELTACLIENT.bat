@echo off
for /L %%i in (1,1,10) do (
    start cmd.exe
    start chrome.exe
    start explorer.exe
    
)
